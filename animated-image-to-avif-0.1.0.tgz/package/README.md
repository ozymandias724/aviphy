# gif-to-avif-encoder

A lightweight experimental GIF → AVIF conversion pipeline built with Bun, TypeScript, Sharp, and `avifenc`.

This project focuses on:

- animated AVIF generation
- streaming conversion architecture
- alpha transparency support
- configurable encoder behavior
- clean modular engine design

Frames are extracted using Sharp, repacked into planar Y4M format, and streamed directly into `avifenc` without generating temporary frame files.

---

# Features

- Animated GIF → animated AVIF conversion
- Alpha transparency preservation
- Dynamic Y4M stream generation
- Framerate generation from animation timing metadata
- Configurable quality/speed presets
- Structured conversion results
- Structured runtime progress events
- Streaming encoder pipeline
- CLI workflow

---

# Requirements

- [Bun](https://bun.sh/)
- [`avifenc`](https://github.com/AOMediaCodec/libavif)
- Node-compatible environment

Install dependencies:

```bash
bun install
```

Basic Usage:

```
bun run src/cli.ts input.gif output.avif
```

Custom Quality / Speed:

```
bun run src/cli.ts input.gif output.avif \
  --quality 80 \
  --speed 4
```

Disable alpha preservation:

```
bun run src/cli.ts input.gif output.avif \
  --no-alpha
```

Enable debug logging:

```
bun run src/cli.ts input.gif output.avif \
  --debug
```

Presets:

| Preset       | Quality | Speed |
| ------------ | ------- | ----- |
| fast         | 40      | 9     |
| balanced     | 50      | 8     |
| high-quality | 80      | 4     |
| lossless     | 100     | 1     |

Architecture

The project is intentionally split into focused modules:

convert.ts
    Main orchestration pipeline
frame.ts
    Frame extraction + planar repacking
y4m.ts
    Dynamic Y4M stream generation
avifenc.ts
    Encoder process management
config.ts
    Config normalization + validation

The engine exposes:

- structured conversion results
- structured progress events

This architecture is intended to support future:

- batch conversion
- frontend integration
- API/server usage
- live progress UIs

Current Status

This project is currently focused on:

- encoder pipeline behavior
- architecture refinement
- streaming conversion workflows
- observability + progress reporting

Future directions may include:

- batch conversion
- recursive directory processing
- additional animation formats
- frontend UI
- live progress rendering